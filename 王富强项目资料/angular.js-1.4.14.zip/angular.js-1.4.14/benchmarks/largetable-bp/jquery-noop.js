//Override me with ?jquery=/bower_components/jquery/dist/jquery.js
